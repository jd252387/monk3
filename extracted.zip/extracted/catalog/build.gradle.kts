plugins {
    java
    id("org.kordamp.gradle.jandex") version "1.1.0"
}

dependencies {
    implementation(enforcedPlatform(libs.quarkus.bom))

    implementation("io.quarkus:quarkus-arc")
    implementation("io.quarkus:quarkus-jackson")

    implementation("org.apache.commons:commons-vfs2:2.10.0")
    implementation("io.etcd:jetcd-core:0.7.7")

    compileOnly(libs.lombok)
    annotationProcessor(libs.lombok)

    testImplementation("io.quarkus:quarkus-junit5")
    testCompileOnly(libs.lombok)
    testAnnotationProcessor(libs.lombok)
}

java {
    toolchain {
        languageVersion = JavaLanguageVersion.of(25)
    }
}

tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
    options.compilerArgs.add("-parameters")
    options.release = 25
}

tasks.withType<Test>().configureEach {
    useJUnitPlatform()
}

// The jandex plugin writes its index into build/resources/main, which the test compile
// classpath consumes; make the ordering explicit so Gradle does not flag an implicit dependency.
tasks.named("compileTestJava") {
    dependsOn(tasks.named("jandex"))
}
