package org.gradle.accessors.dm;

import org.jspecify.annotations.NullMarked;
import org.gradle.api.artifacts.MinimalExternalModuleDependency;
import org.gradle.plugin.use.PluginDependency;
import org.gradle.api.artifacts.ExternalModuleDependencyBundle;
import org.gradle.api.artifacts.MutableVersionConstraint;
import org.gradle.api.provider.Provider;
import org.gradle.api.model.ObjectFactory;
import org.gradle.api.provider.ProviderFactory;
import org.gradle.api.internal.catalog.AbstractExternalDependencyFactory;
import org.gradle.api.internal.catalog.DefaultVersionCatalog;
import java.util.Map;
import org.gradle.api.internal.attributes.AttributesFactory;
import org.gradle.api.internal.artifacts.dsl.CapabilityNotationParser;
import javax.inject.Inject;
import org.gradle.api.GradleException;

/**
 * A catalog of dependencies accessible via the {@code libs} extension.
 */
@NullMarked
public class LibrariesForLibs extends AbstractExternalDependencyFactory {

    private final AbstractExternalDependencyFactory owner = this;
    private final QuarkusLibraryAccessors laccForQuarkusLibraryAccessors = new QuarkusLibraryAccessors(owner);
    private final RestLibraryAccessors laccForRestLibraryAccessors = new RestLibraryAccessors(owner);
    private final VersionAccessors vaccForVersionAccessors = new VersionAccessors(providers, config);
    private final BundleAccessors baccForBundleAccessors = new BundleAccessors(objects, providers, config, attributesFactory, capabilityNotationParser);
    private final PluginAccessors paccForPluginAccessors = new PluginAccessors(providers, config);

    @Inject
    public LibrariesForLibs(DefaultVersionCatalog config, ProviderFactory providers, ObjectFactory objects, AttributesFactory attributesFactory, CapabilityNotationParser capabilityNotationParser) {
        super(config, providers, objects, attributesFactory, capabilityNotationParser);
    }

    /**
     * Dependency provider for <b>lombok</b> with <b>org.projectlombok:lombok</b> coordinates and
     * with version reference <b>lombok</b>
     * <p>
     * This dependency was declared in catalog libs.versions.toml
     */
    public Provider<MinimalExternalModuleDependency> getLombok() {
        return create("lombok");
    }

    /**
     * Group of libraries at <b>quarkus</b>
     */
    public QuarkusLibraryAccessors getQuarkus() {
        return laccForQuarkusLibraryAccessors;
    }

    /**
     * Group of libraries at <b>rest</b>
     */
    public RestLibraryAccessors getRest() {
        return laccForRestLibraryAccessors;
    }

    /**
     * Group of versions at <b>versions</b>
     */
    public VersionAccessors getVersions() {
        return vaccForVersionAccessors;
    }

    /**
     * Group of bundles at <b>bundles</b>
     */
    public BundleAccessors getBundles() {
        return baccForBundleAccessors;
    }

    /**
     * Group of plugins at <b>plugins</b>
     */
    public PluginAccessors getPlugins() {
        return paccForPluginAccessors;
    }

    public static class QuarkusLibraryAccessors extends SubDependencyFactory {
        private final QuarkusCamelLibraryAccessors laccForQuarkusCamelLibraryAccessors = new QuarkusCamelLibraryAccessors(owner);
        private final QuarkusConfigLibraryAccessors laccForQuarkusConfigLibraryAccessors = new QuarkusConfigLibraryAccessors(owner);
        private final QuarkusHibernateLibraryAccessors laccForQuarkusHibernateLibraryAccessors = new QuarkusHibernateLibraryAccessors(owner);
        private final QuarkusRestLibraryAccessors laccForQuarkusRestLibraryAccessors = new QuarkusRestLibraryAccessors(owner);
        private final QuarkusSmallryeLibraryAccessors laccForQuarkusSmallryeLibraryAccessors = new QuarkusSmallryeLibraryAccessors(owner);

        public QuarkusLibraryAccessors(AbstractExternalDependencyFactory owner) { super(owner); }

        /**
         * Dependency provider for <b>bom</b> with <b>io.quarkus.platform:quarkus-bom</b> coordinates and
         * with version reference <b>quarkus</b>
         * <p>
         * This dependency was declared in catalog libs.versions.toml
         */
        public Provider<MinimalExternalModuleDependency> getBom() {
            return create("quarkus.bom");
        }

        /**
         * Dependency provider for <b>junit5</b> with <b>io.quarkus:quarkus-junit5</b> coordinates and
         * with <b>no version specified</b>
         * <p>
         * This dependency was declared in catalog libs.versions.toml
         */
        public Provider<MinimalExternalModuleDependency> getJunit5() {
            return create("quarkus.junit5");
        }

        /**
         * Group of libraries at <b>quarkus.camel</b>
         */
        public QuarkusCamelLibraryAccessors getCamel() {
            return laccForQuarkusCamelLibraryAccessors;
        }

        /**
         * Group of libraries at <b>quarkus.config</b>
         */
        public QuarkusConfigLibraryAccessors getConfig() {
            return laccForQuarkusConfigLibraryAccessors;
        }

        /**
         * Group of libraries at <b>quarkus.hibernate</b>
         */
        public QuarkusHibernateLibraryAccessors getHibernate() {
            return laccForQuarkusHibernateLibraryAccessors;
        }

        /**
         * Group of libraries at <b>quarkus.rest</b>
         */
        public QuarkusRestLibraryAccessors getRest() {
            return laccForQuarkusRestLibraryAccessors;
        }

        /**
         * Group of libraries at <b>quarkus.smallrye</b>
         */
        public QuarkusSmallryeLibraryAccessors getSmallrye() {
            return laccForQuarkusSmallryeLibraryAccessors;
        }

    }

    public static class QuarkusCamelLibraryAccessors extends SubDependencyFactory {

        public QuarkusCamelLibraryAccessors(AbstractExternalDependencyFactory owner) { super(owner); }

        /**
         * Dependency provider for <b>bom</b> with <b>io.quarkus.platform:quarkus-camel-bom</b> coordinates and
         * with version reference <b>quarkus</b>
         * <p>
         * This dependency was declared in catalog libs.versions.toml
         */
        public Provider<MinimalExternalModuleDependency> getBom() {
            return create("quarkus.camel.bom");
        }

    }

    public static class QuarkusConfigLibraryAccessors extends SubDependencyFactory {

        public QuarkusConfigLibraryAccessors(AbstractExternalDependencyFactory owner) { super(owner); }

        /**
         * Dependency provider for <b>yaml</b> with <b>io.quarkus:quarkus-config-yaml</b> coordinates and
         * with <b>no version specified</b>
         * <p>
         * This dependency was declared in catalog libs.versions.toml
         */
        public Provider<MinimalExternalModuleDependency> getYaml() {
            return create("quarkus.config.yaml");
        }

    }

    public static class QuarkusHibernateLibraryAccessors extends SubDependencyFactory {

        public QuarkusHibernateLibraryAccessors(AbstractExternalDependencyFactory owner) { super(owner); }

        /**
         * Dependency provider for <b>validator</b> with <b>io.quarkus:quarkus-hibernate-validator</b> coordinates and
         * with <b>no version specified</b>
         * <p>
         * This dependency was declared in catalog libs.versions.toml
         */
        public Provider<MinimalExternalModuleDependency> getValidator() {
            return create("quarkus.hibernate.validator");
        }

    }

    public static class QuarkusRestLibraryAccessors extends SubDependencyFactory implements DependencyNotationSupplier {

        public QuarkusRestLibraryAccessors(AbstractExternalDependencyFactory owner) { super(owner); }

        /**
         * Dependency provider for <b>rest</b> with <b>io.quarkus:quarkus-rest</b> coordinates and
         * with <b>no version specified</b>
         * <p>
         * This dependency was declared in catalog libs.versions.toml
         */
        public Provider<MinimalExternalModuleDependency> asProvider() {
            return create("quarkus.rest");
        }

        /**
         * Dependency provider for <b>jackson</b> with <b>io.quarkus:quarkus-rest-jackson</b> coordinates and
         * with <b>no version specified</b>
         * <p>
         * This dependency was declared in catalog libs.versions.toml
         */
        public Provider<MinimalExternalModuleDependency> getJackson() {
            return create("quarkus.rest.jackson");
        }

    }

    public static class QuarkusSmallryeLibraryAccessors extends SubDependencyFactory {

        public QuarkusSmallryeLibraryAccessors(AbstractExternalDependencyFactory owner) { super(owner); }

        /**
         * Dependency provider for <b>openapi</b> with <b>io.quarkus:quarkus-smallrye-openapi</b> coordinates and
         * with <b>no version specified</b>
         * <p>
         * This dependency was declared in catalog libs.versions.toml
         */
        public Provider<MinimalExternalModuleDependency> getOpenapi() {
            return create("quarkus.smallrye.openapi");
        }

    }

    public static class RestLibraryAccessors extends SubDependencyFactory {

        public RestLibraryAccessors(AbstractExternalDependencyFactory owner) { super(owner); }

        /**
         * Dependency provider for <b>assured</b> with <b>io.rest-assured:rest-assured</b> coordinates and
         * with <b>no version specified</b>
         * <p>
         * This dependency was declared in catalog libs.versions.toml
         */
        public Provider<MinimalExternalModuleDependency> getAssured() {
            return create("rest.assured");
        }

    }

    public static class VersionAccessors extends VersionFactory  {

        public VersionAccessors(ProviderFactory providers, DefaultVersionCatalog config) { super(providers, config); }

        /**
         * Version alias <b>lombok</b> with value <b>1.18.46</b>
         * <p>
         * If the version is a rich version and cannot be represented as a
         * single version string, an empty string is returned.
         * <p>
         * This version was declared in catalog libs.versions.toml
         */
        public Provider<String> getLombok() { return getVersion("lombok"); }

        /**
         * Version alias <b>quarkus</b> with value <b>3.33.1.1</b>
         * <p>
         * If the version is a rich version and cannot be represented as a
         * single version string, an empty string is returned.
         * <p>
         * This version was declared in catalog libs.versions.toml
         */
        public Provider<String> getQuarkus() { return getVersion("quarkus"); }

    }

    public static class BundleAccessors extends BundleFactory {

        public BundleAccessors(ObjectFactory objects, ProviderFactory providers, DefaultVersionCatalog config, AttributesFactory attributesFactory, CapabilityNotationParser capabilityNotationParser) { super(objects, providers, config, attributesFactory, capabilityNotationParser); }

    }

    public static class PluginAccessors extends PluginFactory {

        public PluginAccessors(ProviderFactory providers, DefaultVersionCatalog config) { super(providers, config); }

        /**
         * Plugin provider for <b>quarkus</b> with plugin id <b>io.quarkus</b> and
         * with version reference <b>quarkus</b>
         * <p>
         * This plugin was declared in catalog libs.versions.toml
         */
        public Provider<PluginDependency> getQuarkus() { return createPlugin("quarkus"); }

    }

}
